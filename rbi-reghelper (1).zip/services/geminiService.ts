import { GoogleGenAI } from "@google/genai";
import { Message } from "../types";

const MODEL_NAME = "gemini-3-pro-preview";

// Initialize the client.
// Ideally, the API key is passed here. Since we can't ask user for input in code due to instructions,
// we assume process.env.API_KEY is available.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateResponse = async (
  history: Message[],
  context: string,
  onStream: (chunk: string) => void
): Promise<string> => {
  try {
    const systemInstruction = `
      You are an expert Banking Regulation Helper AI. 
      Your goal is to assist users with questions related to banking regulations, RBI guidelines, and financial norms.
      
      You have access to the following Reference Material (RBI Handbook):
      """
      ${context}
      """
      
      Instructions:
      1. Answer questions strictly based on the provided Reference Material.
      2. If the answer is found in the material, cite the Chapter or Section if possible.
      3. If the answer is NOT in the material, politely state that the information is not present in the current context/handbook.
      4. Be professional, concise, and accurate.
      5. Format your response using Markdown (e.g., bold for emphasis, lists for steps).
    `;

    // Convert internal message format to Gemini format
    // Filter out system messages from history as we pass system instruction separately
    const historyMessages = history
      .filter(m => m.role !== 'system')
      .map(m => ({
        role: m.role,
        parts: [{ text: m.content }],
      }));

    // The last message is the current user query, so we pop it to send as the new message
    // We create a chat session with the history excluding the last message
    const chat = ai.chats.create({
      model: MODEL_NAME,
      config: {
        systemInstruction: systemInstruction,
        thinkingConfig: { thinkingBudget: 1024 } // Enable thinking for better reasoning on regulations
      },
      history: historyMessages.slice(0, -1), // All except last
    });

    const lastMessage = historyMessages[historyMessages.length - 1];
    if (!lastMessage) throw new Error("No message to send");

    const resultStream = await chat.sendMessageStream({
      message: lastMessage.parts[0].text
    });

    let fullText = "";
    for await (const chunk of resultStream) {
       // chunk is GenerateContentResponse
       const text = chunk.text;
       if (text) {
         fullText += text;
         onStream(fullText);
       }
    }

    return fullText;

  } catch (error) {
    console.error("Gemini API Error:", error);
    throw error;
  }
};