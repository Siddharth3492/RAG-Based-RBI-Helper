import React, { useRef } from 'react';
import { Book, FileText, Upload, Trash2, ShieldCheck } from 'lucide-react';
import { ContextFile } from '../types';

interface SidebarProps {
  files: ContextFile[];
  onAddFile: (file: ContextFile) => void;
  onRemoveFile: (id: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ files, onAddFile, onRemoveFile }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result as string;
      onAddFile({
        id: crypto.randomUUID(),
        name: file.name,
        content: text,
        type: 'user',
      });
    };
    reader.readAsText(file);
    
    // Reset input
    if (fileInputRef.current) {
        fileInputRef.current.value = '';
    }
  };

  return (
    <div className="w-80 bg-slate-900 text-white flex flex-col h-screen shadow-xl border-r border-slate-800">
      <div className="p-6 border-b border-slate-800">
        <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-blue-600 rounded-lg">
                <ShieldCheck className="w-6 h-6 text-white" />
            </div>
            <div>
                <h1 className="text-xl font-bold tracking-tight">RBI RegHelper</h1>
                <p className="text-xs text-slate-400">Powered by Gemini 3 Pro</p>
            </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4">
        <div className="mb-6">
          <h2 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-4">
            Knowledge Base
          </h2>
          <div className="space-y-3">
            {files.map((file) => (
              <div 
                key={file.id}
                className={`group flex items-start gap-3 p-3 rounded-lg border transition-all duration-200 ${
                  file.type === 'default' 
                    ? 'bg-blue-900/20 border-blue-700/50' 
                    : 'bg-slate-800 border-slate-700'
                }`}
              >
                <div className="mt-1">
                  {file.type === 'default' ? (
                    <Book className="w-4 h-4 text-blue-400" />
                  ) : (
                    <FileText className="w-4 h-4 text-emerald-400" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-slate-200 truncate leading-snug">
                    {file.name}
                  </p>
                  <p className="text-xs text-slate-500 mt-1">
                    {file.content.length.toLocaleString()} chars
                  </p>
                </div>
                {file.type === 'user' && (
                  <button
                    onClick={() => onRemoveFile(file.id)}
                    className="opacity-0 group-hover:opacity-100 text-slate-500 hover:text-red-400 transition-opacity"
                    title="Remove file"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="p-4 bg-slate-800 border-t border-slate-700">
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileUpload}
          accept=".txt,.md,.json,.csv"
          className="hidden"
        />
        <button
          onClick={() => fileInputRef.current?.click()}
          className="w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-500 text-white py-3 px-4 rounded-lg font-medium transition-colors"
        >
          <Upload className="w-4 h-4" />
          Upload Guidelines
        </button>
        <p className="text-[10px] text-center text-slate-500 mt-2">
            Supports .txt, .md, .json (Max 5MB)
        </p>
      </div>
    </div>
  );
};