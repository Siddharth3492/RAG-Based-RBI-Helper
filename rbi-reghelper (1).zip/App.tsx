import React, { useState, useEffect } from 'react';
import { Sidebar } from './components/Sidebar';
import { ChatInterface } from './components/ChatInterface';
import { Message, ContextFile } from './types';
import { RBI_HANDBOOK_TEXT } from './data/rbiHandbook';
import { generateResponse } from './services/geminiService';

const App: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [files, setFiles] = useState<ContextFile[]>([
    {
      id: 'default-handbook',
      name: 'RBI Handbook 2025',
      content: RBI_HANDBOOK_TEXT,
      type: 'default',
    },
  ]);
  const [isLoading, setIsLoading] = useState(false);

  const handleAddFile = (file: ContextFile) => {
    setFiles((prev) => [...prev, file]);
  };

  const handleRemoveFile = (id: string) => {
    setFiles((prev) => prev.filter((f) => f.id !== id));
  };

  const handleSendMessage = async (content: string) => {
    const userMessage: Message = {
      id: crypto.randomUUID(),
      role: 'user',
      content,
      timestamp: Date.now(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setIsLoading(true);

    // Create a temporary model message for streaming
    const modelMessageId = crypto.randomUUID();
    setMessages((prev) => [
      ...prev,
      {
        id: modelMessageId,
        role: 'model',
        content: '',
        timestamp: Date.now(),
      },
    ]);

    try {
      // Aggregate context from all files
      const fullContext = files.map(f => `--- SOURCE: ${f.name} ---\n${f.content}\n`).join('\n');

      await generateResponse(
        [...messages, userMessage],
        fullContext,
        (streamedContent) => {
          setMessages((prev) =>
            prev.map((msg) =>
              msg.id === modelMessageId ? { ...msg, content: streamedContent } : msg
            )
          );
        }
      );
    } catch (error) {
      console.error("Failed to generate response", error);
      setMessages((prev) => [
        ...prev,
        {
            id: crypto.randomUUID(),
            role: 'system',
            content: 'Error: Failed to connect to Gemini API. Please check your connection or API key.',
            timestamp: Date.now()
        }
      ])
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar
        files={files}
        onAddFile={handleAddFile}
        onRemoveFile={handleRemoveFile}
      />
      <ChatInterface
        messages={messages}
        onSendMessage={handleSendMessage}
        isLoading={isLoading}
      />
    </div>
  );
};

export default App;