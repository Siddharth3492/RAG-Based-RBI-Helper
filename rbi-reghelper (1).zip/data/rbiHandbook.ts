export const RBI_HANDBOOK_TEXT = `
HANDBOOK ON REGULATIONS AT A GLANCE
RESERVE BANK OF INDIA DEPARTMENT OF REGULATION FEBRUARY 2025

CHAPTER I - LEGISLATIVE FRAMEWORK
01. Regulation of Banks: Reserve Bank of India Act, 1934; Banking Regulation Act, 1949; The Recovery Of Debts And Bankruptcy (RDB) Act, 1993; SARFAESI Act, 2002; PML Act, 2002; Companies Act, 2013.
02. Regulation of NBFCs, ARC and Credit Information Companies: RBI Act 1934; NHB Act 1987; SARFAESI Act 2002; PML Act 2002; CIC (Regulation) Act 2005; Factoring Regulation Act 2011.
03. Regulation of Cooperative Banks: RBI Act 1934; BR Act 1949; Multi-State Co-operative Act 2002; PML Act 2002; Various State Co-operative Acts.

CHAPTER II - LICENSING OF NEW INSTITUTIONS
II.1 LICENSING OF BANKS
Universal Banks: Paid-up/Net worth ₹1,000 crore. Resident Individuals with > 10 years experience.
Small Finance Banks: Paid-up/Net worth ₹300 crore. Resident Indian Citizens with > 10 years experience.
Urban Cooperative Banks: ₹12.5 lakh - ₹4 crore depending on category.
Rural Cooperative Banks: State Govt declares particular society as StCB/CCB.

II.2 NBFC REGISTRATION
NBFC-ICC (Type I): ₹2 crore NOF
NBFC-ICC (Type II): ₹10 crore NOF
NBFC-P2P: ₹2 crore NOF
NBFC-AA: ₹2 crore NOF
NBFC-MFI: ₹10 crore NOF
NBFC-FACTOR: ₹10 crore NOF
NBFC-HFC: ₹20 crore NOF
MGC: ₹100 crore NOF
IDF-NBFC: ₹300 crore NOF
NBFC-IFC: ₹300 crore NOF
ARC: ₹300 crore NOF
NBFC-CIC: Core Investment company ≥ ₹100 crore total assets.

CHAPTER III: Governance and Ownership Framework
Includes Fit and Proper Criteria, Roles of Chairman and CEO, Audit Committees, etc.
Scale-based governance framework for NBFC (BL, ML, UL).

CHAPTER IV: Prudential Norms and Capital Regulations
IV.1 Capital Regulations prescribed by BCBS: Basel I, Basel II, Basel III (CET1 4.5%, Leverage Ratio, etc.)
IV.2 Market and Liquidity Risk: Standardized Approach, Internal Models.
IV.3 Credit Risk:
- Housing Finance LTV/Risk Weights
- SCBs and HFCs: Up to 30L (LTV <=80, RW 35), >30L to 75L (LTV <=80, RW 35), >75L (LTV <=75, RW 50).
- UCBs: Up to 30L (LTV <=75, RW 50).
IV.3.a.iii Digital Lending: DLG cap at 5% of loan portfolio.
IV.8 Capital Adequacy:
- SCBs (Basel III): CET1 5.5%, Tier 1 7%, CRAR 9%.
- SFBs: Tier 1 7.5%, CRAR 15%.
- NBFC-ML/UL: Tier 1 10%, CRAR 15%.

IV.10 Dividend Declaration:
- SCBs: NNPA < 7%
- UCBs: NNPA < 5%
- NBFCs: NNPA < 6%

CHAPTER V: Conduct related regulations
V.1 Interest Rate Framework for NBFCs: Deregulated.
V.2 Interest Rate Framework for SCBs and Co-op Banks: Deregulated (except savings < 1 Lakh which is uniform).
V.4 Fair Practices Code: Loan appraisal, disbursement, non-discrimination, release of securities.
V.5 Recent Instructions: Penal charges (not penal interest), reset of floating rates on EMI loans.

CHAPTER VI: Resolution of Regulated Entities
Mergers and Amalgamations governed by BR Act 1949 and Companies Act 2013.
Resolution of NBFCs under Section 45MBA of RBI Act.
`;