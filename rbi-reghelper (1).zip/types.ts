export interface Message {
  id: string;
  role: 'user' | 'model' | 'system';
  content: string;
  timestamp: number;
}

export interface ContextFile {
  id: string;
  name: string;
  content: string;
  type: 'default' | 'user';
}

export interface ChatState {
  messages: Message[];
  isLoading: boolean;
  error: string | null;
}